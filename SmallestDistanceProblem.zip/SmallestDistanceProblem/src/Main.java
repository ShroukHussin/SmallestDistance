import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		 Scanner in;
	        System.out.println("Enter num of edges ");
	    	in = new Scanner(System.in); 
	    	int num = Integer.parseInt(in.nextLine());
	    	 SmallestDistance g = new SmallestDistance(num);
	    	 for(int i=0 ; i< num-1;i++)
	    	 {
	    		 System.out.println("add edge num "+ (i+1));
	    		 in = new Scanner(System.in); 
	    		 String str = in.nextLine();
	    		 String[] arrOfStr = str.split(" ");
				if( 1<= Integer.parseInt(arrOfStr[0]) && Integer.parseInt(arrOfStr[1]) <= num){
				 g.addEdge(Integer.parseInt(arrOfStr[0]), Integer.parseInt(arrOfStr[1]));
			 }
	    	 }
	    	 System.out.println("enter number of clubs then add edge number where club exists ");
	    	in = new Scanner(System.in); 
	    	int q= Integer.parseInt(in.nextLine()); 
	       if(1<=q && q<=(num-1) ) {                 
	    	   System.out.println( "id of the country of the club which will be accepted is  "+g.VertixOfSmallestDistance(q, 1));
	    	   
	       }

	}

}
