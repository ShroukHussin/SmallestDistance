import java.util.Arrays;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Vector;

public class SmallestDistance {
	int n;      //num of vertices
	LinkedList<Integer> adjListArray[];
	 public SmallestDistance(int n){
		 if(2<=n && n<=1000 ) {
		 this.n =n;
	    adjListArray = new LinkedList[n];
	  
	    for(int i = 0; i < n; i++)
	     { 
	      adjListArray[i] = new LinkedList<>(); 
	     } 
		 }
		 else {
			 System.out.println(" you must add number (N) in range   2<=N<=1000  ");
			 return;
			 
		 }
		 
	 }

	 public void addEdge( int src, int dest) 
	 {   if( 1<=src && dest<=n)
	 {
	     // Add an edge from src to dest and vise versa bec it's undirected graph.  
	   adjListArray[src-1].add(dest-1); 
	     
	    adjListArray[dest-1].add(src-1); 
	 }
	     
	 } 
	 //find the smallest distance between src and dis
	 int Smallestdistance( int src,    int dis, int n)
	 {
		 Vector<Boolean> visited = new Vector<Boolean>(n); 
	     //intialize vested with false
	     for (int i = 0; i < n; i++) { 
	         visited.addElement(false); 
	     } 
	    
	     // Initialize distances as 0 
	     Vector<Integer> distance = new Vector<Integer>(n); 
	       
	     for (int i = 0; i < n; i++) { 
	         distance.addElement(0); 
	     }  
	     //queue
	     LinkedList<Integer> q = new LinkedList<Integer>();
	     //start point src
	     q.add(src-1);  // -1 as  it  stored in array of linked list which  start with 0
	     visited.setElementAt(true, src-1);
	     while(!q.isEmpty() )
	     {
	    	 int x = q.peek();  ///take head of the queue
	         q.poll();         //remove head of queue
	         for(int i =0 ; i< adjListArray[x].size();i++)
	         {
	        	 if(visited.elementAt( adjListArray[x].get(i))) {
	        		 continue;
	        	 }
	        	 distance.setElementAt(distance.get(x) + 1, adjListArray[x].get(i));
	        	 q.add( adjListArray[x].get(i)); 
	             visited.setElementAt(true, adjListArray[x].get(i));
	         }
	     }
	     return distance.get(dis-1);
	     
	 }
	  public int [] verticesToCheck(int q) {
		 Scanner in ; 
		 int []Q  = new int[0];  //array of countries contains club
	      if( 1<=q &&  q<=(n-1) ) {
	          Q = new int[q];
	          for (int i = 0; i < q; i++) {
	              in = new Scanner(System.in);
	              int num = Integer.parseInt(in.nextLine());
	              Q[i] = num;
	          }
	          return Q;
	      }
	      else {
	          System.out.println(" enter valid num of clubs ");
	          return null;
	      }
	 }
	 
	 
	   // 1<=u,v<=N 1<=Q<=(N-1)    
	  public int VertixOfSmallestDistance(int q,int v)
	 {
		  int []Q =verticesToCheck( q)  ;
	      Arrays.sort(Q);
		 /* for(int i=0 ;i< q;i++)
			 {
				 System.out.println(Q[i]);
			 }
			 */
		  int min = Q[0];
		 // System.out.println(min);
		  for(int i = 0 ; i<q ;i++) 
		  {  //System.out.println(distance(Q[i],v, n));
			  if(Smallestdistance(Q[i],v, n) < Smallestdistance(min,v, n))
			  {
				  min = Q[i];
			  }
		  }
		  return min;
		  
	 }

}
